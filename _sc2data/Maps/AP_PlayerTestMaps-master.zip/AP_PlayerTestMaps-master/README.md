# AP Test maps
This repo contains test maps for Terran Race for ArchipleagoPlayer.SC2Mod

The map with upgrades also has some unused upgrades enabled for testing. See the map triggers
